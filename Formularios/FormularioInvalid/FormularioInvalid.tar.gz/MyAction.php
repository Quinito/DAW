<?php
echo"nombre:".$_POST["usuario"];
echo"Edad:".$_POST["miedad"];
echo"Email:".$_POST["miemail"];
?>