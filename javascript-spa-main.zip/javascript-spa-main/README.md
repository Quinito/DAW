# git clone https://github.com/techweber/javascript-spa.git
# cd javascript-spa
# double click on spa.html
# Enjoy!
